package smartcard.redone.com.mykad;

/**
 * Created by user on 2/18/2016.
 */
public class MyKad_Data {
    private String name;
    private String gender;
    private String nric;
    private String oldIC;
    private String citizenship;
    private String race;
    private String religion;
    private String address1;
    private String address2;
    private String address3;
    private String postcode;
    private String state;
    private String city;
    private String dateOfBirth;
    private String dateOfIssuance;
    private String eastMsianOrigin;
    private String placeOfBirth;

    public String GetAddress1()
    {
        return this.address1;
    }

    public String GetAddress2()
    {
        return this.address2;
    }

    public String GetAddress3()
    {
        return this.address3;
    }

    public String GetCitizenship()
    {
        return this.citizenship;
    }

    public String GetCity()
    {
        return this.city;
    }

    public String GetDateOfBirth()
    {
        return this.dateOfBirth;
    }

    public String GetDateOfIssuance()
    {
        return this.dateOfIssuance;
    }

    public String GetEastMsianOrigin()
    {
        return this.eastMsianOrigin;
    }

    public String GetGender()
    {
        return this.gender;
    }

    public String GetName()
    {
        return this.name;
    }

    public String GetNric()
    {
        return this.nric;
    }

    public String GetOldIC()
    {
        return this.oldIC;
    }

    public String GetPlaceOfBirth()
    {
        return this.placeOfBirth;
    }

    public String GetPostcode()
    {
        return this.postcode;
    }

    public String GetRace()
    {
        return this.race;
    }

    public String GetReligion()
    {
        return this.religion;
    }

    public String GetState()
    {
        return this.state;
    }

    /*starting of set*/

    public void SetAddress1(String param)
    {
        this.address1 = param;
    }

    public void SetAddress2(String param)
    {
        this.address2 = param;
    }

    public void SetAddress3(String param)
    {
        this.address3 = param;
    }

    public void SetCitizenship(String param)
    {
        this.citizenship = param;
    }

    public void SetCity(String param)
    {
        this.city = param;
    }

    public void SetDateOfBirth(String param)
    {
        this.dateOfBirth = param;
    }

    public void SetDateOfIssuance(String param)
    {
        this.dateOfIssuance = param;
    }

    public void SetEastMsianOrigin(String param)
    {
        this.eastMsianOrigin = param;
    }

    public void SetGender(String param)
    {
        this.gender = param;
    }

    public void SetName(String param)
    {
        this.name = param;
    }

    public void SetNric(String param)
    {
        this.nric = param;
    }

    public void SetOldIC(String param)
    {
        this.oldIC = param;
    }

    public void SetPlaceOfBirth(String param)
    {
        this.placeOfBirth = param;
    }

    public void SetPostcode(String param)
    {
        this.postcode = param;
    }

    public void SetRace(String param)
    {
        this.race = param;
    }

    public void SetReligion(String param)
    {
        this.religion = param;
    }

    public void SetState(String param)
    {
        this.state = param;
    }

}
