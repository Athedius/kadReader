ACS Smart Card I/O Android Library
Advanced Card Systems Ltd.



Introduction
------------

The library "acssmcio" provides classes and interfaces for communicating with
ACS Bluetooth readers. It is based on the service provider interface
(TerminalFactorySpi) from Java Smart Card I/O API defined by JSR 268 [1].

The Java Smart Card I/O API defines a Java API for communication with Smart
Cards using ISO/IEC 7816-4 APDUs. It thereby allows Java applications to
interact with applications running on the Smart Card, to store and retrieve data
on the card, etc.

The library "smartcardio" imports Java packages from OpenJDK:
- javax.smartcardio
- sun.net.www
- sun.nio.cs
- sun.security.action
- sun.security.jca
- sun.security.util

To install libraries to your development environment, see the section
"Installation".

[1] https://jcp.org/en/jsr/detail?id=268



Release Notes
-------------

Version:      0.5.3
Release Date: 17/5/2022

System Requirements

- Android 4.3 (Jelly Bean MR2) or above.

Development Environment

- Android Studio Chipmunk 2021.2.1 or above. See Android Developers [1] for more
  information.

[1] https://developer.android.com/

Supported Readers

- ACR3901U-S1/ACR3901T-W1
- ACR1255U-J1
- ACR1255U-J1 V2
- AMR220-C



Installation
------------

1. To try the demo project, select Open from File menu on Android Studio. Choose
   "BLETest".

2. You can also run the demo project without Android Studio installed. Copy
   "BLETest-x.y.z.apk" to your Android device. Launch the installation by
   clicking the file icon on any File Explorer application.

3. To use the class library to your project, copy "acssmcio-x.y.z.aar" and
   "smartcardio-x.y.z.aar" to your "app\libs" folder.

4. Go to File -> Project Structure -> Dependencies.

5. In the "Declared Dependencies" tab, click and select "Jar Dependency" in the
   dropdown.

6. In the "Add Jar/Aar Dependency" dialog, enter the path to
   "libs/acssmcio-x.y.z.aar" and select "implementation" configuration.

7. Follow the above steps to add "libs/smartcardio-x.y.z.aar".

8. You will see the following lines from your app's "build.gradle" file.

   implementation files('libs/acssmcio-x.y.z.aar')
   implementation files('libs/smartcardio-x.y.z.aar')



History
-------

Library: smartcardio

v0.1.3 (17/5/2022)
- Update build.gradle for Android Studio Bumblebee 2021.1.1 Patch 3.
- Move the directory "sun" to "openjdk" in order to fix NoSuchMethodError
  exception for sun.security.jca.GetInstance due to non-SDK interface
  restrictions in Android 12.
- Remove unused namespace in AndroidManifest.xml.
- Add XML declaration to AndroidManifest.xml.

v0.1.2 (15/10/2019)
- Migrate to AndroidX.
- Update versionName to 0.1.2 in build.gradle.

v0.1.1 (9/10/2018)
- Update build.gradle for Android Studio 3.2.
- Update versionName to 0.1.1 in build.gradle.

v0.1.0 (28/8/2018)
- New release.
- Import javax.smartcardio and related packages.



Library: acssmcio

v0.5.3 (17/5/2022)
- Update build.gradle for Android Studio Bumblebee 2021.1.1 Patch 3.
- Remove unused namespace and permissions in AndroidManifest.xml.
- Add XML declaration to AndroidManifest.xml.
- Update package documentation.

v0.5.2 (4/6/2020)
- Clear the response before writing NAK frame in AMR220-C.
- Update package documentation.
- Update versionName to 0.5.2 in build.gradle.

v0.5.1 (27/2/2020)
- Initialize maximum data rate to 75000 bps in AMR220-C ICC.
- Handle interrupt frame in AMR220-C firmware v2.02.11 or later.
- Initialize the card state to unknown in AMR220-C ICC and PICC.
- Update the card state in AMR220-C initialization.
- Update versionName to 0.5.1 in build.gradle.

v0.5.0 (15/10/2019)
- Change TerminalTimeouts.DEFAULT_TIMEOUT to public.
- Add BluetoothTerminalManager.getDeviceInfo().
- Update package documentation.
- Migrate to AndroidX.
- Update versionName to 0.5.0 in build.gradle.

v0.4.1 (9/10/2018)
- Update build.gradle for Android Studio 3.2.
- Implement error handling and recovery in AMR220-C.
- Lock the response buffer in AMR220-C initialization.
- Update versionName to 0.4.1 in build.gradle.

v0.4.0 (28/8/2018)
- Handle the following error codes from ACR3901U-S1:
  ERROR_SUCCESSIVE_AUTHENTICATION_FAILED (9)
  ERROR_T1_CARD_OPERATION_FAILED (10)
- Implement extended APDU for AMR220-C >= v1.06.
- Fix sequence number synchronization bug in AMR220-C.
- Change the retry count for ACK frame to 10 in AMR220-C.
- Implement authentication for AMR220-C >= v2.00.
- Check the response length in ACR3901U-S1 authentication.
- Fix the wrong response length when transmitting the command to ACR3901U-S1.
- Check the response length when decrypting the response from ACR3901U-S1,
  ACR1255U-J1 and AMR220-C.
- Add BluetoothTerminalManager.getBatteryStatus().
- Add BluetoothTerminalManager.getBatteryLevel().
- Avoid null value for firmware revision in ACR3901U-S1 and ACR1255U-J1
  initialization.
- Remove redundant authenticated check in ACR1255U-J1 initialization.
- Remove javax.smartcardio and related packages.
- Add smartcardio to dependencies in build.gradle.
- Update package documentation.
- Update versionName to 0.4.0 in build.gradle.

v0.3.1 (4/7/2018)
- Fix a bug that T=0 APDU > 256 bytes failed in ACR3901U-S1.
- Skip the response if start byte is missing in ACR1255U-J1.
- Verify the response after decrypting the frame in ACR3901U-S1.
- Update versionName to 0.3.1 in build.gradle.

v0.3.0 (17/5/2018)
- Add the following readers support:
  ACR3901U-S1/ACR3901T-W1
  ACR1255U-J1
  ACR1255U-J1 V2
- Implement card insertion and removal in Bluetooth CardTerminals.list().
- Update build.gradle for Android Studio 3.1.2.
- Guard the concurrent access of current state in Bluetooth CardTerminal.
- Update documentation in BluetoothTerminal.setMasterKey().
- Update documentation in BluetoothTerminalManager.TERMINAL_TYPE_ACR3901U_S1.
- Skip invalid frames when transmitting the command to AMR220-C.
- Add BluetoothTerminalManager.getTerminalType().
- Update package documentation.
- Update versionName to 0.3.0 in build.gradle.

v0.2.0 (27/3/2018)
- Add TransmitOptions to modify the default behaviour in transmitting APDUs.
- Replace warm reset with cold reset in Bluetooth Card.connect() and
  Card.disconnect().
- Update package documentation.
- Update build.gradle for Android Studio 3.1.
- Update versionName to 0.2.0 in build.gradle.

v0.1.4 (9/2/2018)
- Optimize frame type evaluation when transmitting the command to AMR220-C.
- Fix scan problem on Android 4.3 and 4.4.x. Some devices running Android 4.3 or
  4.4.x may have a problem that there are no devices returned from the callback
  if 128-bit service UUIDs are passed to BluetoothAdapter.startLeScan().
- Set service discovery timeout and notification timeout from parameter in
  AMR220-C initialization.
- Check the error code when transmitting the APDU to PICC.
- Update versionName to 0.1.4 in build.gradle.

v0.1.3 (24/1/2018)
- Synchronize the sequence number when transmitting the command to AMR220-C.
- Ensure GATT is closed when connecting to the device.
- Return same Card object for direct in Bluetooth CardTerminal.connect().
- Change the data type of timeout parameter from int to long.
- Change service discovery timeout to 5 seconds in AMR220-C initialization.
- Cleanup AndroidManifest.xml.
- Cleanup access modifiers.
- Update versionName to 0.1.3 in build.gradle.

v0.1.2 (4/1/2018)
- Update build.gradle for Android Studio 3.0.1.
- Lock the list of terminals before finding terminals by device in
  BluetoothTerminalManager.
- Wait for device disconnection when disconnecting the device. It fixes the
  problem that the connection state may not be updated properly and the library
  is still accessing resources which are released by the system if the time
  between connection and disconnection is too short.
- Disable the notification when disconnecting AMR220-C.
- Lock the shared resource before accessing it.
- Replace Condition.signalAll() with signal(). Because the API call is
  synchronous, using Condition.signal() is more suitable.
- Set the card to null when initializing the device. If the device is
  disconnected, then set the card to null in order to update the card status.
- Initialize the device before connecting AMR220-C.
- Update versionName to 0.1.2 in build.gradle.

v0.1.1 (13/10/2017)
- Add Factory(Object) to AcsBluetooth. It fixes NoSuchAlgorithmException on some
  Android platforms.
- Check null before accessing scanner in BluetoothTerminalManager. If Bluetooth
  is not enabled on Android 5.0 or above,
  BluetoothAdapter.getBluetoothLeScanner() returns null.

v0.1.0 (29/9/2017)
- New release.



Demo

v0.5.3 (17/5/2022)
- Update build.gradle for Android Studio Chipmunk 2021.2.1.
- Add android:exported to MainActivity in AndroidManifest.xml.
- Add Android 12 Bluetooth permissions to AndroidManifest.xml.
- Request a permission to enable Bluetooth on Android 12 in MainActivity.
- Fix non-final resource ID issue in MainActivity.onOptionsItemSelected().
- Check the value of column index in MainActivity.getDisplayName().
- Set MainActivity.TerminalAdapter.mTerminals to final.
- Fix NullPointerException in onDialogNegativeClick().
- Fix NullPointerException in onTerminalTimeoutsDialogNegativeClick().
- Request permissions to scan terminals in MainActivity.
- Select a file using ActivityResultLauncher in MainActivity.
- Remove unused WRITE_EXTERNAL_STORAGE request in MainActivity.
- Remove unused MainActivity.onActivityResult().
- Remove unused MainActivity.onRequestPermissionsResult().
- Remove unused MainActivity.REQUEST_* constants.
- Update gradlew.
- Update gradlew.bat.
- Update versionName to 0.5.3 in build.gradle.

v0.5.2 (4/6/2020)
- Fix location permission issue on Android 10.
- Update build.gradle for Android Studio 4.0.
- Use Context.getExternalFilesDir() in MainActivity.getDir().
- Use a documents provider to select a file in MainActivity.
- Use Context.getExternalFilesDir() in FileChooser.
- Check if the path is null in FileChooser.refresh().
- Return if dirs or files is null in FileChooser.refresh().
- Update versionName to 0.5.2 in build.gradle.

v0.5.1 (27/2/2020)
- Update build.gradle for Android Studio 3.5.3.
- Add item "Show/Hide Card State" to menu in MainActivity.
- Update versionName to 0.5.1 in build.gradle.
- Update build.gradle for Android Studio 3.6.

v0.5.0 (15/10/2019)
- Update resource files from Android Studio 3.2.1.
- Replace sp with dp for layout in dialog_master_key.xml.
- Replace getActivity() with requireActivity() in MasterKeyDialogFragment.
- Fix rotation issue in MasterKeyDialogFragment.
- Add ScrollView to dialog_master_key.xml.
- Rename IDs in MasterKeyDialogFragment and dialog_master_key.xml.
- Add TerminalTimeoutsDialogFragment to show the timeouts settings.
- Add item "Get Device Information" to menu in MainActivity.
- Update build.gradle for Android Studio 3.5.1.
- Update the documentation in MainActivity.
- Use setPreferencesFromResource() in SettingsFragment.
- Migrate to AndroidX.
- Remove "from" from disconnecting message in MainActivity.
- Update versionName to 0.5.0 in build.gradle.

v0.4.1 (9/10/2018)
- Change Boolean to boolean in MainActivity.onCreate().
- Update ConstraintLayout to 1.1.3 in build.gradle.
- Update build.gradle for Android Studio 3.2.
- Update versionName to 0.4.1 in build.gradle.

v0.4.0 (28/8/2018)
- Update build.gradle for Android Studio 3.1.4.
- Add item "Get Battery Status" to menu in MainActivity.
- Add item "Get Battery Level" to menu in MainActivity.
- Add smartcardio to dependencies in build.gradle.
- Add smartcardio to settings.gradle.
- Update versionName to 0.4.0 in build.gradle.

v0.3.1 (4/7/2018)
- Update build.gradle for Android Studio 3.1.3.
- Update ConstraintLayout to 1.1.2 in build.gradle.
- Update versionName to 0.3.1 in build.gradle.

v0.3.0 (17/5/2018)
- Add TerminalTypeDialogFragment to select a terminal type for scan.
- Add "@since 0.2" to SettingsFragment.
- Add "@since 0.2" to SettingsActivity.
- Add "ACR1255U-J1 V2" to terminal_types_array in strings.xml.
- Update build.gradle for Android Studio 3.1.2.
- Add MasterKeyDialogFragment to show the master key settings.
- Update versionName to 0.3.0 in build.gradle.

v0.2.0 (27/3/2018)
- Remove an empty line before MainActivity.isExternalStorageWritable().
- Replace // with /* ... */ in MainActivity.onCreate().
- Add SettingsActivity to control Transmit Options.
- Update build.gradle for Android Studio 3.1.
- Update versionName to 0.2.0 in build.gradle.

v0.1.4 (9/2/2018)
- Remove redundant casts in MainActivity.onCreate().
- Remove redundant initializers in MainActivity.checkLine(),
  MainActivity.compareResponse() and MainActivity.onCreate().
- Set the layout if window is not null in FileChooser().
- Add missing String type to ArrayAdapter in FileChooser.refresh().
- Add missing annotations in FileChooser.refresh().
- Simplify the expression in FileChooser.refresh().
- Use StringBuilder for string concatenation in Logger.logBuffer() and
  Logger.logHexString().
- Update versionName to 0.1.4 in build.gradle.

v0.1.3 (24/1/2018)
- Add /release to app/.gitignore.
- Update resource files from Android Studio 3.0.1.
- Use StringBuilder for string concatenation in Hex.toHexString().
- Update versionName to 0.1.3 in build.gradle.

v0.1.2 (4/1/2018)
- Update build.gradle for Android Studio 3.0.1.
- Update versionName to 0.1.2 in build.gradle.

v0.1.1 (13/10/2017)
- Request the permission before selecting file in MainActivity.
- Select the file in MainActivity.onRequestPermissionsResult().
- Remove redundant !isEnabled() in MainActivity.onResume().

v0.1.0 (29/9/2017)
- New release.



File Contents
-------------

API Documentation:  doc
Sample Application: BLETest
Android Package:    BLETest-0.5.3.apk
Class Library:      BLETest\app\libs\acssmcio-0.5.3.aar
                    BLETest\app\libs\smartcardio-0.1.3.aar
Scripts:            scripts



Support
-------

In case of problem, please contact ACS through:

Web Site: http://www.acs.com.hk/
E-mail: info@acs.com.hk
Tel: +852 2796 7873
Fax: +852 2796 1286



-------------------------------------------------------------------------------
Copyright (c) 2017-2022, Advanced Card Systems Ltd. All rights reserved.

OpenJDK
Copyright (c) 1998-2016, Oracle and/or its affiliates. All rights reserved.

This code is free software; you can redistribute it and/or modify it
under the terms of the GNU General Public License version 2 only, as
published by the Free Software Foundation.  Oracle designates this
particular file as subject to the "Classpath" exception as provided
by Oracle in the LICENSE file that accompanied this code.

This code is distributed in the hope that it will be useful, but WITHOUT
ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License
version 2 for more details (a copy is included in the LICENSE file that
accompanied this code).

You should have received a copy of the GNU General Public License version
2 along with this work; if not, write to the Free Software Foundation,
Inc., 51 Franklin St, Fifth Floor, Boston, MA 02110-1301 USA.

Android is a trademark of Google Inc.
